import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { employeesApi } from '@/api/employees.api';
import { QUERY_KEYS } from '@/constants/queryKeys';

export const useEmployees = (params) =>
  useQuery({
    queryKey: QUERY_KEYS.EMPLOYEES(params),
    queryFn: () => employeesApi.getAll(params),
    placeholderData: (prev) => prev,
  });

export const useActiveEmployees = () =>
  useQuery({
    queryKey: QUERY_KEYS.EMPLOYEES_ACTIVE,
    queryFn: employeesApi.getActiveList,
    staleTime: 1000 * 60 * 10,
  });

// Service PO create/edit's Delivery Head dropdown — response envelope not yet confirmed against
// the exact shape the new backend endpoint returns, so `select` defensively unwraps either
// `{ data: [...] }` or a bare array.
export const useEligibleDeliveryHeads = () =>
  useQuery({
    queryKey: QUERY_KEYS.ELIGIBLE_DELIVERY_HEADS,
    queryFn: employeesApi.getEligibleDeliveryHeads,
    select: (data) => {
      if (Array.isArray(data)) return data;
      if (Array.isArray(data?.data)) return data.data;
      return [];
    },
    staleTime: 1000 * 60 * 5,
  });

export const useEmployee = (id) =>
  useQuery({
    queryKey: QUERY_KEYS.EMPLOYEE(id),
    queryFn: () => employeesApi.getById(id),
    enabled: !!id,
  });

export const useCreateEmployee = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: employeesApi.create,
    onSuccess: () => Promise.all([
        qc.invalidateQueries({ queryKey: ['employees'] }),
        qc.invalidateQueries({ queryKey: ['users'] })
      ]),
  });
};

export const useUpdateEmployee = (id) => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload) => employeesApi.update(id, payload),
    onSuccess: () => Promise.all([
        qc.invalidateQueries({ queryKey: ['employees'] }),
        qc.invalidateQueries({ queryKey: QUERY_KEYS.EMPLOYEE(id) }),
        qc.invalidateQueries({ queryKey: ['users'] })
      ]),
  });
};

export const useDeleteEmployee = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: employeesApi.delete,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['employees'] }),
  });
};

export const useImportEmployees = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: employeesApi.import,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['employees'] }),
  });
};

export const useToggleEmployeeStatus = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }) => employeesApi.update(id, { status }),
    onSuccess: () => Promise.all([
        qc.invalidateQueries({ queryKey: ['employees'] }),
        qc.invalidateQueries({ queryKey: ['users'] })
      ]),
  });
};
