import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Save } from 'lucide-react';
import { useServicePO, useCreateServicePO, useUpdateServicePO } from '@/hooks/useServicePOs';
import { useActiveClients } from '@/hooks/useClients';
import { useProjectsByClient } from '@/hooks/useProjects';
import { useActiveServiceTypes } from '@/hooks/useServiceTypes';
import { useActiveServiceCategories } from '@/hooks/useServiceCategories';
import { useEligibleDeliveryHeads } from '@/hooks/useEmployees';
import { useNotification } from '@/hooks/useNotification';
import { extractApiError } from '@/services/apiClient';
import { ROUTES } from '@/constants/routes';
import {
  Form, FormField, FormItem, FormLabel, FormControl, FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { SearchableSelect } from '@/components/ui/searchable-select';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from "@/components/ui/sheet";

// Matches the backend's create-time contract: required, 2-30 chars, uppercase alphanumeric plus
// -, _, / — the server uppercases before validating/storing, so lowercase input is fine here too.
const SERVICE_PO_CODE_PATTERN = /^[A-Z0-9_/-]{2,30}$/;
const SERVICE_PO_CODE_MESSAGE =
  'Must be 2–30 characters: letters, numbers, hyphens (-), underscores (_), or slashes (/) only.';

// PUT still leaves service_po_code optional, so the field is only required on create — same
// pattern check applies either way once something has actually been typed.
const servicePoCodeField = (required) =>
  z
    .string()
    .trim()
    .transform((v) => v.toUpperCase())
    .superRefine((v, ctx) => {
      if (v === '') {
        if (required) ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Service PO Number is required' });
        return;
      }
      if (!SERVICE_PO_CODE_PATTERN.test(v)) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: SERVICE_PO_CODE_MESSAGE });
      }
    });

const poSchema = (isEdit) => z
  .object({
    service_po_name: z
      .string()
      .min(3, 'Service PO name must be at least 3 characters')
      .max(200, 'Service PO name cannot exceed 200 characters'),
    service_po_code: servicePoCodeField(!isEdit),
    client_id: z.coerce.number({ required_error: 'Client is required' }).positive('Client is required'),
    project_id: z.coerce.number({ required_error: 'Project is required' }).positive('Project is required'),
    delivery_head_employee_id: z.coerce
      .number({ required_error: 'Delivery Head is required' })
      .positive('Delivery Head is required'),
    service_type_id: z.coerce
      .number({ required_error: 'Service type is required' })
      .positive('Service type is required'),
    po_value: z.preprocess(
      (v) => (v === '' || v == null ? undefined : Number(v)),
      z.number().positive('PO value must be positive').optional()
    ),
    start_date: z.string().min(1, 'Start date is required'),
    end_date: z.string().min(1, 'End date is required'),
    expected_man_hours: z.preprocess(
      (v) => (v === '' || v == null ? undefined : Number(v)),
      z.number().positive('Expected hours must be positive').optional()
    ),
    service_description: z.string().min(1, 'Service description is required').max(1000),
    invoice_frequency: z.string().min(1, 'Invoice frequency is required'),
    status: z.enum(['in-progress', 'completed', 'on-hold', 'pending', 'cancelled', 'closed']).default('in-progress'),
  })
  .refine(
    (data) => {
      if (!data.start_date || !data.end_date) return true;
      return new Date(data.end_date) >= new Date(data.start_date);
    },
    { message: 'End date must be on or after start date', path: ['end_date'] }
  );

// Field names for the eligible-delivery-heads response aren't confirmed against the backend
// contract yet, so this reads common variants defensively rather than assuming one exact shape.
const formatDeliveryHeadLabel = (e) => {
  const name = e.full_name ?? e.employee_name ?? e.name ?? '';
  const code = e.employee_code ?? e.code ?? '';
  const email = e.email ?? '';
  return [name, code && `(${code})`, email && `— ${email}`].filter(Boolean).join(' ');
};

const FormSkeleton = () => (
  <div className="space-y-4 p-4">
    {Array.from({ length: 4 }).map((_, i) => (
      <div key={i} className="space-y-2 h-14 bg-muted animate-pulse rounded-md" />
    ))}
  </div>
);

const ServicePOForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;
  const { success, error: showError } = useNotification();

  const { data: po, isPending: isLoadingPO } = useServicePO(id);
  const { data: activeClients = [], isPending: isLoadingClients } = useActiveClients();
  const { data: serviceTypes = [], isPending: isLoadingTypes } = useActiveServiceTypes();
  const { data: activeCategories = [], isPending: isLoadingCategories } = useActiveServiceCategories();
  const {
    data: deliveryHeads = [],
    isPending: isLoadingDeliveryHeads,
    isError: isDeliveryHeadsError,
    error: deliveryHeadsError,
  } = useEligibleDeliveryHeads();
  const createMutation = useCreateServicePO();
  const updateMutation = useUpdateServicePO(id);

  const [selectedCategory, setSelectedCategory] = useState('');

  const form = useForm({
    resolver: zodResolver(poSchema(isEdit)),
    defaultValues: {
      service_po_name: '',
      service_po_code: '',
      client_id: '',
      project_id: '',
      delivery_head_employee_id: '',
      service_type_id: '',
      po_value: '',
      start_date: '',
      end_date: '',
      expected_man_hours: '',
      service_description: '',
      invoice_frequency: '',
      status: 'in-progress',
    },
  });

  // Project dropdown is scoped to whichever Client is currently selected — refetches whenever
  // it changes, and is disabled until a Client is picked (see Project field below).
  const watchedClientId = form.watch('client_id');
  const {
    data: clientProjects = [],
    isPending: isLoadingProjects,
    isError: isProjectsError,
    error: projectsError,
  } = useProjectsByClient(watchedClientId);

  useEffect(() => {
    if (po && isEdit) {
      if (serviceTypes.length > 0 && po.service_type_id) {
        const typeObj = serviceTypes.find(t => t.id === po.service_type_id);
        if (typeObj) {
          setSelectedCategory(String(typeObj.service_category_id));
        }
      }
      form.reset({
        service_po_name: po.service_po_name ?? '',
        service_po_code: po.service_po_code ?? '',
        client_id: po.client_id ?? '',
        project_id: po.project_id ?? po.project?.id ?? '',
        delivery_head_employee_id:
          po.delivery_head_employee_id ?? po.delivery_head?.id ?? po.delivery_head_employee?.id ?? '',
        service_type_id: po.service_type_id ?? '',
        po_value: po.po_value ?? '',
        start_date: po.start_date ? po.start_date.slice(0, 10) : '',
        end_date: po.end_date ? po.end_date.slice(0, 10) : '',
        expected_man_hours: po.expected_man_hours ?? '',
        service_description: po.service_description ?? '',
        invoice_frequency: po.invoice_frequency ?? '',
        status: po.status ?? 'in-progress',
      });
    }
  }, [po, isEdit, form, serviceTypes]);

  const onSubmit = (values) => {
    let is_billable = false;
    if (selectedCategory && activeCategories.length > 0) {
      const category = activeCategories.find((c) => String(c.id) === String(selectedCategory));
      if (category && category.name.toLowerCase() === 'billable') {
        is_billable = true;
      }
    }

    const clean = Object.fromEntries(
      Object.entries(values).filter(([, v]) => v !== '' && v != null)
    );
    clean.is_billable = is_billable;

    const mutation = isEdit ? updateMutation : createMutation;
    mutation.mutate(clean, {
      onSuccess: () => {
        success(isEdit ? 'Service PO updated successfully.' : 'Service PO created successfully.');
        handleClose();
      },
      onError: (err) => {
        const message = extractApiError(err);
        // Backend has no structured field-errors array for this one — a plain {message} 400 — so
        // it's matched by its known prefix and pinned to the field instead of a generic toast.
        if (/^Service PO code /i.test(message)) {
          form.setError('service_po_code', { type: 'server', message });
        } else {
          showError(message);
        }
      },
    });
  };

  const handleClose = () => {
    navigate(ROUTES.SERVICE_POS);
  };

  const isSubmitting = createMutation.isPending || updateMutation.isPending;

  if (isEdit && isLoadingPO) return <FormSkeleton />;

  return (
    <Sheet open={true} onOpenChange={(open) => !open && handleClose()}>
      <SheetContent 
        side="right" 
        className="w-full sm:max-w-3xl p-0 flex flex-col bg-white overflow-hidden"
        onInteractOutside={(e) => e.preventDefault()}
      >
        <SheetHeader className="px-5 py-3 border-b">
          <SheetTitle className="text-base font-medium text-left">{isEdit ? 'Edit Service PO' : 'New Service PO'}</SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto">
          {isEdit && isLoadingPO ? (
            <FormSkeleton />
          ) : (
            <Form {...form}>
              <form id="servicepo-form" onSubmit={form.handleSubmit(onSubmit)} className="p-5 flex flex-col gap-6">
                
                {/* PO Details */}
                <div className="space-y-3">
                  <h3 className="text-xs font-semibold text-foreground border-b pb-1">PO Details</h3>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">

              <FormField
                control={form.control}
                name="service_po_name"
                render={({ field }) => (
                  <FormItem className="space-y-1 sm:col-span-2">
                    <FormLabel className="text-[13px]">
                      <span className="text-destructive">*</span> Service PO Name
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Annual Support Services" className="h-8 text-sm" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="service_po_code"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">
                      {!isEdit && <span className="text-destructive">*</span>} Service PO Number
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. PO-1001" className="h-8 text-sm uppercase" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="client_id"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">
                      <span className="text-destructive">*</span> Client
                    </FormLabel>
                    <SearchableSelect
                      options={activeClients.map(c => ({
                        value: String(c.id),
                        label: c.client_name
                      }))}
                      value={field.value}
                      onValueChange={(val) => {
                        field.onChange(val ? parseInt(val, 10) : undefined);
                        // Changing Client invalidates whatever Project was picked for the
                        // previous Client — never carry it over (§3).
                        form.setValue('project_id', '');
                      }}
                      disabled={isLoadingClients}
                      placeholder="Select client"
                      searchPlaceholder="Search client..."
                      className="h-8 text-sm"
                    />
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="project_id"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">
                      <span className="text-destructive">*</span> Project
                    </FormLabel>
                    <SearchableSelect
                      options={clientProjects.map(p => ({
                        value: String(p.id),
                        label: p.project_name
                      }))}
                      value={field.value}
                      onValueChange={(val) => field.onChange(val ? parseInt(val, 10) : undefined)}
                      disabled={!watchedClientId || isLoadingProjects}
                      placeholder={watchedClientId ? 'Select project' : 'Select a client first'}
                      searchPlaceholder="Search project..."
                      emptyMessage={isProjectsError ? 'Failed to load projects.' : 'No projects found for this client.'}
                      className="h-8 text-sm"
                    />
                    {isProjectsError && (
                      <p className="text-[11px] text-destructive">
                        Couldn't load projects: {extractApiError(projectsError)}
                      </p>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="delivery_head_employee_id"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">
                      <span className="text-destructive">*</span> Delivery Head
                    </FormLabel>
                    <SearchableSelect
                      options={deliveryHeads.map((e) => ({
                        value: String(e.id ?? e.employee_id),
                        label: formatDeliveryHeadLabel(e),
                      }))}
                      value={field.value}
                      onValueChange={(val) => field.onChange(val ? parseInt(val, 10) : undefined)}
                      disabled={isLoadingDeliveryHeads}
                      placeholder="Select delivery head"
                      searchPlaceholder="Search by name, code or email..."
                      emptyMessage={isDeliveryHeadsError ? 'Failed to load delivery heads.' : 'No eligible delivery heads found.'}
                      className="h-8 text-sm"
                    />
                    {isDeliveryHeadsError && (
                      <p className="text-[11px] text-destructive">
                        Couldn't load delivery heads: {extractApiError(deliveryHeadsError)}
                      </p>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-1">
                <FormLabel className="text-[13px]">
                  <span className="text-destructive">*</span> Service PO Category
                </FormLabel>
                  <SearchableSelect
                    options={activeCategories.map(c => ({
                      value: String(c.id),
                      label: c.name
                    }))}
                    value={selectedCategory}
                    onValueChange={(val) => {
                      setSelectedCategory(val);
                      form.setValue('service_type_id', '');
                    }}
                    disabled={isLoadingCategories}
                    placeholder="Select category"
                    searchPlaceholder="Search category..."
                    className="h-8 text-sm"
                  />
              </div>

              <FormField
                control={form.control}
                name="service_type_id"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">
                      <span className="text-destructive">*</span> Service PO Type
                    </FormLabel>
                        <SearchableSelect
                          options={serviceTypes
                            .filter((t) => t.service_category_id === Number(selectedCategory))
                            .map(c => ({
                              value: String(c.id),
                              label: c.service_type_name
                            }))}
                          value={field.value}
                          onValueChange={(val) => field.onChange(val ? parseInt(val, 10) : undefined)}
                          disabled={isLoadingTypes || !selectedCategory}
                          placeholder="Select service type"
                          searchPlaceholder="Search service type..."
                          className="h-8 text-sm"
                        />
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">Status</FormLabel>
                    <SearchableSelect showSearch={false}
                      options={[
                        { label: "In Progress", value: "in-progress" },
                        { label: "Completed", value: "completed" },
                        { label: "On Hold", value: "on-hold" },
                        { label: "Pending", value: "pending" },
                        { label: "Cancelled", value: "cancelled" },
                        { label: "Closed", value: "closed" }
                      ]}
                      value={field.value}
                      onValueChange={field.onChange}
                      placeholder="Select status"
                      searchPlaceholder="Search status..."
                      className="h-8 text-sm w-full"
                    />
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="service_description"
                render={({ field }) => (
                  <FormItem className="space-y-1 sm:col-span-2">
                    <FormLabel className="text-[13px]"><span className="text-destructive">*</span> Service PO Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Describe the services included in this PO…"
                        rows={2}
                        className="resize-none text-sm"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
                  </div>
                </div>

                {/* Commercial */}
                <div className="space-y-3">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="po_value"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">PO Value (INR)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="e.g. 500000"
                        className="h-8 text-sm"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="expected_man_hours"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">Expected Man-Hours</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        step="0.5"
                        placeholder="e.g. 1200"
                        className="h-8 text-sm"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="start_date"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">
                      <span className="text-destructive">*</span> Start Date 
                    </FormLabel>
                    <FormControl>
                      <Input type="date" className="h-8 text-sm" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="end_date"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]">
                      <span className="text-destructive">*</span> End Date 
                    </FormLabel>
                    <FormControl>
                      <Input type="date" className="h-8 text-sm" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="invoice_frequency"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-[13px]"><span className="text-destructive">*</span> Invoice Frequency</FormLabel>
                    <SearchableSelect showSearch={false}
                      options={[
                        { label: "Monthly", value: "monthly" },
                        { label: "Milestone based", value: "milestone-based" },
                        { label: "Yearly AMC", value: "yearly-amc" },
                        { label: "Internal - No Invoice", value: "internal-no-invoice" },
                        { label: "POC", value: "poc" }
                      ]}
                      value={field.value}
                      onValueChange={field.onChange}
                      placeholder="Select frequency"
                      searchPlaceholder="Search frequency..."
                      className="h-8 text-sm w-full"
                    />
                    <FormMessage />
                  </FormItem>
                )}
              />

                  </div>
                </div>
              </form>
            </Form>
          )}
        </div>

        <SheetFooter className="px-5 py-3 border-t flex items-center justify-end gap-3 sm:justify-end">
          <Button type="button" variant="outline" size="sm" onClick={handleClose}>
            Cancel
          </Button>
          <Button type="submit" size="sm" disabled={isSubmitting} form="servicepo-form">
            <Save className="mr-1.5 h-3.5 w-3.5" />
            {isSubmitting ? 'Saving…' : isEdit ? 'Save Changes' : 'Create Service PO'}
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
};

export default ServicePOForm;
