import { useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useDispatch, useSelector } from 'react-redux';
import { selectSidebarCollapsed, toggleSidebar, setSidebarCollapsed } from '@/store/slices/uiSlice';
import { selectIsDirty, selectDirtyMessage, clearDirty } from '@/store/slices/navigationGuardSlice';
import { cn } from '@/utils/cn';
import { useAuth } from '@/hooks/useAuth';
import { useFormModules, useForms } from '@/hooks/useForms';
import { resolveFormRoute } from '@/constants/rbacForms';
import { ROUTES } from '@/constants/routes';
import { ChevronLeft, ChevronRight, UserPlus, Shield, ClipboardList, UserCog, Landmark, Network } from 'lucide-react';
import ConfirmDialog from '@/components/common/ConfirmDialog';
import ScrollOnHoverText from '@/components/common/ScrollOnHoverText';

// A Platform Admin (top of the RBAC hierarchy, §0) sees ONLY these nav items — everything else
// the RBAC-driven buildNavGroups() would otherwise show is skipped for them. Platform Admin
// only provisions Admins now (§6.1) — Entity Admin/Company management moved down a tier.
const SUPER_ADMIN_NAV_GROUPS = [
  {
    label: 'Administration',
    items: [
      { label: 'Admins', icon: UserPlus, to: ROUTES.ADMINS, exact: false },
      { label: 'Role Master', icon: Shield, to: ROUTES.ROLES, exact: false },
      { label: 'Forms Master', icon: ClipboardList, to: ROUTES.FORMS, exact: false },
      { label: 'Organization Overview', icon: Network, to: ROUTES.ORGANIZATION_OVERVIEW, exact: true },
    ],
  },
];

// Modules hidden from the sidebar for everyone except users with the BU Admin role (the RBAC
// redesign's per-company "first admin", renamed from the old "Company Admin"), regardless of
// what any role's own form mappings say — a hardcoded UI restriction on top of the RBAC data.
const RESTRICTED_MODULES = ['administration'];

// Screens gated by role name directly (allowedRoles on the route) rather than a Form Master
// row — their nav items are injected on top of the RBAC-driven groups below rather than
// resolved from accessibleForms, same pattern as the BU Admin bypass above.
const ENTITY_ADMIN_MANAGEMENT_ROLES = ['Admin'];
const TEAM_MAPPING_ROLES = ['Service PO Admin'];

// Builds one nav group per module, one item per form — driven entirely by the RBAC
// accessible-forms map (module -> [{ id, name }]) so a user only ever sees what their
// roles actually grant. Section AND item order follow each row's real Form Master `seq`
// (moduleRank/formRank, resolved from GET /forms/modules + GET /forms — see useMenuRank
// below), not the API's own (alphabetical) key order — no module/form name is hardcoded
// here, so a re-sequence on the Form Master screen is reflected with no frontend change.
// A form with no known route mapping is dropped (and logged) rather than rendered as a
// dead link — see constants/rbacForms.js.
const buildNavGroups = (accessibleForms, { isSuperAdmin, moduleRank, formRank }) =>
  Object.entries(accessibleForms ?? {})
    .filter(
      ([moduleName]) => isSuperAdmin || !RESTRICTED_MODULES.includes(moduleName.trim().toLowerCase())
    )
    .map(([moduleName, forms]) => ({
      label: moduleName,
      items: (forms ?? [])
        .map((form) => {
          const cfg = resolveFormRoute(form.name);
          if (!cfg) {
            console.warn(
              `[RBAC] Sidebar: no route mapping for form "${form.name}" (module "${moduleName}"). ` +
              `Add it to src/constants/rbacForms.js.`
            );
            return null;
          }
          return { label: form.name, icon: cfg.icon, to: cfg.to, exact: cfg.exact };
        })
        .filter(Boolean)
        .sort((a, b) => formRank(moduleName, a.label) - formRank(moduleName, b.label)),
    }))
    .filter((group) => group.items.length > 0)
    .sort((a, b) => moduleRank(a.label) - moduleRank(b.label));

// Real module/form ordering, sourced from the same Form Master data the /forms screen
// manages (GET /forms/modules for module seq, GET /forms for per-module form seq) —
// available to every authenticated user regardless of whether they hold the "Forms" RBAC
// permission themselves (that permission only gates writes). Unknown names (not yet
// resolvable — e.g. a brand-new module before this query has loaded) rank last rather than
// erroring, so the nav still renders, just unsorted for that item until the seq data lands.
const useMenuRank = () => {
  const { data: moduleRows } = useFormModules({ status: 'active' });
  const { data: formsList } = useForms({ status: 'active' });

  return useMemo(() => {
    const moduleSeq = new Map();
    (moduleRows ?? []).forEach((m) => moduleSeq.set(m.form_name.trim().toLowerCase(), m.seq));

    const formSeq = new Map();
    (formsList?.data ?? []).forEach((f) => {
      if (f.module_name != null) {
        formSeq.set(`${f.module_name.trim().toLowerCase()}::${f.form_name.trim().toLowerCase()}`, f.seq);
      }
    });

    return {
      moduleRank: (moduleName) => moduleSeq.get(moduleName.trim().toLowerCase()) ?? Number.MAX_SAFE_INTEGER,
      formRank: (moduleName, formName) =>
        formSeq.get(`${moduleName.trim().toLowerCase()}::${formName.trim().toLowerCase()}`) ?? Number.MAX_SAFE_INTEGER,
    };
  }, [moduleRows, formsList]);
};

const isActive = (to, pathname, exact) => {
  if (exact) return pathname === to;
  return pathname === to || pathname.startsWith(to + '/');
};

// Indented child link rendered below a parent with children
const SubNavItem = ({ item, onNavAttempt }) => {
  const { pathname } = useLocation();
  const active = pathname === item.to;
  const [hovered, setHovered] = useState(false);

  return (
    <Link
      to={item.to}
      onClick={(e) => onNavAttempt(e, item.to)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className={cn(
        'relative flex items-center rounded-md py-1 pl-8 pr-3 text-xs transition-colors min-w-0',
        active
          ? 'text-sidebar-foreground font-medium bg-sidebar-hover/70'
          : 'text-sidebar-foreground/55 hover:text-sidebar-foreground hover:bg-sidebar-hover/40'
      )}
      title={item.label}
    >
      {active && (
        <span className="absolute left-[18px] top-1/2 -translate-y-1/2 h-3.5 w-0.5 rounded-full bg-primary/70" />
      )}
      <ScrollOnHoverText text={item.label} hovered={hovered} className="min-w-0" />
    </Link>
  );
};

const NavItem = ({ item, collapsed, onNavAttempt }) => {
  const { pathname } = useLocation();
  const active = isActive(item.to, pathname, item.exact);
  const hasChildren = !collapsed && Array.isArray(item.children) && item.children.length > 0;
  const [hovered, setHovered] = useState(false);

  return (
    <div>
      <Link
        to={item.to}
        onClick={(e) => onNavAttempt(e, item.to)}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        className={cn(
          'nav-item group relative flex items-center gap-3 transition-all min-w-0',
          active && 'active',
          collapsed && 'justify-center px-2'
        )}
        title={item.label}
      >
        {active && (
          <span className="absolute left-0 top-1/2 -translate-y-1/2 h-5 w-0.5 rounded-r-full bg-primary" />
        )}
        <item.icon className={cn('shrink-0', collapsed ? 'h-5 w-5' : 'h-4 w-4')} />
        <AnimatePresence initial={false}>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: 'auto' }}
              exit={{ opacity: 0, width: 0 }}
              transition={{ duration: 0.15 }}
              className="min-w-0"
            >
              <ScrollOnHoverText text={item.label} hovered={hovered} />
            </motion.span>
          )}
        </AnimatePresence>
      </Link>

      {/* Sub-items — only rendered when sidebar is expanded */}
      <AnimatePresence initial={false}>
        {hasChildren && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.15 }}
            className="overflow-hidden"
          >
            {/* Vertical connector line */}
            <div className="relative ml-[22px] mt-0.5 mb-1 border-l border-sidebar-border/60 pl-0">
              {item.children.map((child) => (
                <SubNavItem key={child.to} item={child} onNavAttempt={onNavAttempt} />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const Sidebar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const collapsed = useSelector(selectSidebarCollapsed);
  const { pathname } = useLocation();
  const { accessibleForms, hasRole, isPlatformAdmin } = useAuth();
  // BU Head is an additive peer of BU Admin with identical form/permission access (§14 of the
  // BU Head spec) — extends the same bypass BU Admin already gets, never a standalone concept.
  const isSuperAdmin = hasRole('BU Admin', 'BU Head');
  const canViewEntityAdmins = hasRole(...ENTITY_ADMIN_MANAGEMENT_ROLES);
  const canViewTeamMapping = hasRole(...TEAM_MAPPING_ROLES);
  const { moduleRank, formRank } = useMenuRank();
  // isPlatformAdmin is derived from the single role every login returns (§0) — overrides the
  // normal accessible-forms-driven nav entirely.
  const navGroups = useMemo(() => {
    if (isPlatformAdmin) return SUPER_ADMIN_NAV_GROUPS;
    const base = buildNavGroups(accessibleForms, { isSuperAdmin, moduleRank, formRank });

    const injected = [];
    if (canViewEntityAdmins) {
      injected.push({ group: 'Entity Management', item: { label: 'Entity Admins', icon: Landmark, to: ROUTES.ENTITY_ADMINS, exact: false } });
    }
    if (canViewTeamMapping) {
      injected.push({ group: 'People', item: { label: 'Team Mapping', icon: UserCog, to: ROUTES.TEAM_MAPPINGS, exact: true } });
    }
    if (injected.length === 0) return base;

    return injected.reduce((groups, { group: groupLabel, item }) => {
      const idx = groups.findIndex((g) => g.label.trim().toLowerCase() === groupLabel.toLowerCase());
      if (idx === -1) return [...groups, { label: groupLabel, items: [item] }];
      // Entity Admins should lead its group, ahead of the RBAC-driven BU Admin Master item.
      const prepend = groupLabel === 'Entity Management';
      return groups.map((g, i) => (i === idx ? { ...g, items: prepend ? [item, ...g.items] : [...g.items, item] } : g));
    }, base);
  }, [accessibleForms, isSuperAdmin, isPlatformAdmin, canViewEntityAdmins, canViewTeamMapping, moduleRank, formRank]);

  // Guards navigation away from a page with unsaved changes (e.g. Timesheet
  // Import Detail's Modified Hours edits) — any page can opt in via the
  // useUnsavedChangesGuard hook, which is what populates this global flag.
  const isDirty = useSelector(selectIsDirty);
  const dirtyMessage = useSelector(selectDirtyMessage);
  const [pendingTo, setPendingTo] = useState(null);

  const handleNavAttempt = (e, to) => {
    if (!isDirty) return;
    e.preventDefault();
    setPendingTo(to);
  };

  // Drawer on mobile: start closed, and close again after each navigation
  useEffect(() => {
    if (window.innerWidth < 768) dispatch(setSidebarCollapsed(true));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  return (
    <>
      {/* Mobile backdrop — closes the drawer on tap */}
      {!collapsed && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={() => dispatch(toggleSidebar())}
        />
      )}

      <motion.aside
        animate={{ width: collapsed ? 64 : 260 }}
        transition={{ duration: 0.2, ease: 'easeInOut' }}
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex h-full shrink-0 flex-col bg-sidebar border-r border-sidebar-border overflow-hidden transition-transform duration-200',
          'md:relative md:z-auto md:translate-x-0',
          collapsed ? '-translate-x-full md:translate-x-0' : 'translate-x-0'
        )}
      >
      {/* Logo */}
      <div className={cn(
        'flex h-16 shrink-0 items-center border-b border-sidebar-border px-4 gap-3',
        collapsed ? 'justify-center px-2' : ''
      )}>
        <motion.div
          className="relative flex shrink-0 items-center justify-center"
          initial={{ opacity: 0, scale: 0.7, rotate: -8 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 0.5 }}
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.94 }}
        >
          <motion.img
            src="/logo.svg"
            alt="Logo"
            className={cn("object-contain", collapsed ? "w-10" : "h-12")}
            animate={{
              scale: [1, 1.15, 1],
              rotate: [0, 2, 0, -2, 0],
              filter: [
                'drop-shadow(0 0 4px rgba(139,92,246,0.5))',
                'drop-shadow(0 0 16px rgba(37,99,235,0.8))',
                'drop-shadow(0 0 4px rgba(139,92,246,0.5))',
              ],
            }}
            transition={{ duration: 2.8, repeat: Infinity, ease: 'easeInOut' }}
          />
        </motion.div>
        <AnimatePresence initial={false}>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: 'auto' }}
              exit={{ opacity: 0, width: 0 }}
              transition={{ duration: 0.15 }}
              className="font-bold text-lg text-white whitespace-nowrap overflow-hidden"
            >
              Trackio
            </motion.span>
          )}
        </AnimatePresence>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto overflow-x-hidden py-2 px-2 space-y-2 scrollbar-thin">
        {navGroups.map((group) => (
          <div key={group.label} className="space-y-px">
            <AnimatePresence initial={false}>
              {!collapsed && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="px-3 pt-2 pb-1 text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/30 whitespace-nowrap"
                >
                  {group.label}
                </motion.p>
              )}
            </AnimatePresence>
            {group.items.map((item) => (
              <NavItem key={item.to} item={item} collapsed={collapsed} onNavAttempt={handleNavAttempt} />
            ))}
          </div>
        ))}
      </nav>

      {/* Collapse toggle */}
      <div className="shrink-0 border-t border-sidebar-border p-2">
        <button
          onClick={() => dispatch(toggleSidebar())}
          className={cn(
            'flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-sidebar-foreground/50',
            'hover:bg-sidebar-hover hover:text-sidebar-foreground transition-colors',
            collapsed && 'justify-center px-2'
          )}
        >
          {collapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <>
              <ChevronLeft className="h-4 w-4" />
              <span>Collapse</span>
            </>
          )}
        </button>
      </div>
      </motion.aside>

      <ConfirmDialog
        open={!!pendingTo}
        onOpenChange={(open) => !open && setPendingTo(null)}
        title="Leave without saving?"
        description={dirtyMessage || 'You have unsaved changes. If you leave now, they will be lost.'}
        confirmLabel="Leave"
        cancelLabel="Stay"
        variant="destructive"
        onConfirm={() => {
          const to = pendingTo;
          setPendingTo(null);
          dispatch(clearDirty());
          navigate(to);
        }}
      />
    </>
  );
};

export default Sidebar;
