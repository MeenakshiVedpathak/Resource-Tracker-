import { useQuery, useQueries } from '@tanstack/react-query';
import { employeeProjectsApi } from '@/api/employeeProjects.api';
import { QUERY_KEYS } from '@/constants/queryKeys';
import { useAuth } from '@/hooks/useAuth';

// A single-BU employee's mapped projects (the common case): the plain header-driven call, scoped
// by whichever BU the interceptor puts on X-Company-Id.
const useEmployeeMappedProjectsSingleBu = (enabled) =>
  useQuery({
    queryKey: QUERY_KEYS.EMPLOYEE_PROJECTS,
    queryFn: () => employeeProjectsApi.getMappedProjects(),
    enabled,
  });

// GET /employee-timesheets/projects is scoped by the request's X-Company-Id, i.e. whichever BU is
// globally "active" — see apiClient's request interceptor. The navbar's BU switcher is commented
// out (UserMenu.jsx), so an employee mapped to more than one BU has no way to change that, and a
// plain call here only ever returns the active BU's projects: mapped-under-a-different-BU projects
// silently disappear, same undercount pattern as [[bu-scope-all-bus-undercounts]]. Fan out one
// call per BU instead and merge, deduped by id (a Service PO belongs to exactly one BU, so no
// cross-BU id collisions are expected).
const useEmployeeMappedProjectsAcrossBus = (businessUnits) => {
  const queries = useQueries({
    queries: businessUnits.map((bu) => ({
      queryKey: [...QUERY_KEYS.EMPLOYEE_PROJECTS, bu.id],
      queryFn: () => employeeProjectsApi.getMappedProjects(bu.id),
      enabled: !!bu.id,
    })),
  });

  const seen = new Map();
  queries.forEach((q) => (q.data ?? []).forEach((project) => {
    if (!seen.has(project.id)) seen.set(project.id, project);
  }));

  return {
    data: Array.from(seen.values()),
    isLoading: queries.some((q) => q.isLoading),
    isError: queries.some((q) => q.isError),
  };
};

export const useEmployeeMappedProjects = () => {
  const { businessUnits } = useAuth();
  const multiBu = businessUnits.length > 1;

  const single = useEmployeeMappedProjectsSingleBu(!multiBu);
  const acrossBus = useEmployeeMappedProjectsAcrossBus(multiBu ? businessUnits : []);

  return multiBu ? acrossBus : single;
};
