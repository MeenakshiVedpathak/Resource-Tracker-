import apiClient, { explicitBuScope } from '@/services/apiClient';

// Only the Service POs/projects mapped to the logged-in employee — the backend is the source
// of truth for this mapping (employee-servicepo-mapping), never the full Service PO list
// filtered client-side. `buId` scopes the request to one specific BU (via X-Company-Id) instead
// of whichever BU is globally active — see useEmployeeMappedProjects for why that matters for an
// employee mapped to more than one BU.
export const employeeProjectsApi = {
  getMappedProjects: (buId) =>
    apiClient.get('/employee-timesheets/projects', { ...(buId != null ? explicitBuScope(buId) : {}) })
      .then((r) => r.data?.data ?? []),
};
