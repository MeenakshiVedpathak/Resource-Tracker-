import { useEffect, useMemo, useState } from 'react';
import { Save, Trash2, X } from 'lucide-react';
import { useEmployeeMonthlyWorkLog, useSaveEmployeeMonthlyWorkLog, useDeleteEmployeeMonthlyWorkLog } from '@/hooks/useMyTeam';
import { useNotification } from '@/hooks/useNotification';
import { extractApiError } from '@/services/apiClient';
import { STANDARD_MONTHLY_HOURS } from '@/components/employee/MonthlyHoursCard';
import { AutoResizeTextarea } from '@/components/employee/WorkLogEntryTable';
import { formatHoursMinutes } from '@/utils/formatters';
import { cn } from '@/utils/cn';
import EmptyState from '@/components/common/EmptyState';
import ConfirmDialog from '@/components/common/ConfirmDialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { SearchableSelect } from '@/components/ui/searchable-select';
import { Skeleton } from '@/components/ui/skeleton';

// A hierarchy node nested under a Service PO (Parent/Child) is returned for display only — the
// Manager may only ever log against the Service PO container itself here (a future capability
// covers per-node logging). Matches every other endpoint in this app's convention for marking a
// non-top-level row, so whichever of these fields the backend actually sends is covered.
const isTopLevelServicePO = (po) =>
  (po.depth ?? 0) === 0 && !(po.ancestorKeys?.length) && po.hierarchy_node_id == null && po.parent_id == null;

// Field names aren't confirmed yet (this endpoint is net-new) — accepts every plausible variant
// so a naming mismatch degrades gracefully instead of silently blanking the row.
const normalizePO = (po) => ({
  id: String(po.service_po_id ?? po.id),
  label: po.service_po_name ?? po.label ?? po.name ?? po.service_po_code ?? `Service PO #${po.service_po_id ?? po.id}`,
  existingHours: Number(po.hours ?? po.existing_hours ?? po.total_hours ?? 0),
  existingDescription: po.description ?? po.existing_description ?? '',
});

// Per-Employee drawer for "Log Work for My Team" — Manual Entry mode. Opened from the Employee
// list in ManagerFillWorkLog.jsx; the parent mounts this with `key={employee.id}` so switching
// Employees always starts from a fresh instance instead of carrying over stale entries/errors.
// Distinct from Timesheet Approval (ManagerTimesheetApproval.jsx), which only approves/rejects
// entries the Employee submitted themself: everything saved here is created already-approved (see
// the banner below), so this is a different action entirely, not another way to reach the same
// review queue.
const ManagerFillWorkLogDrawer = ({ employee, monthYear, monthLabel, open, onOpenChange }) => {
  const { success } = useNotification();

  const [entries, setEntries] = useState([]);
  const [addPoId, setAddPoId] = useState('');
  const [formError, setFormError] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);

  const employeeId = employee?.id ?? null;

  const {
    data: workLog,
    isFetching: isLoadingWorkLog,
    isError: isWorkLogError,
    error: workLogError,
  } = useEmployeeMonthlyWorkLog(employeeId, monthYear, { enabled: open && !!employeeId && !!monthYear });

  const availablePOs = useMemo(
    () => (workLog?.service_pos ?? []).filter(isTopLevelServicePO).map(normalizePO),
    [workLog],
  );

  const hadExistingEntries = availablePOs.some((po) => po.existingHours > 0 || po.existingDescription);

  // Resets the editable rows to whatever's already on the server once this Employee/Month's data
  // loads — this is a replace-save, so editing an existing submission has to start from its real
  // current state, not an empty list.
  useEffect(() => {
    if (!workLog) {
      setEntries([]);
      return;
    }
    setEntries(
      availablePOs
        .filter((po) => po.existingHours > 0 || po.existingDescription)
        .map((po) => ({
          service_po_id: po.id,
          label: po.label,
          hours: po.existingHours ? String(po.existingHours) : '',
          description: po.existingDescription,
        }))
    );
    setFormError(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workLog]);

  const addedIds = useMemo(() => new Set(entries.map((e) => e.service_po_id)), [entries]);
  const addOptions = availablePOs
    .filter((po) => !addedIds.has(po.id))
    .map((po) => ({ value: po.id, label: po.label }));

  const totalHours = entries.reduce((sum, e) => sum + Number(e.hours || 0), 0);
  const overCap = totalHours > STANDARD_MONTHLY_HOURS;

  const saveMutation = useSaveEmployeeMonthlyWorkLog();
  const deleteMutation = useDeleteEmployeeMonthlyWorkLog();

  // Picking a Service PO adds its row immediately — no separate "Add New" click needed. The
  // selection is reset right after so the picker is ready for the next pick and the just-added
  // PO (now excluded from `addOptions`) never lingers as a stale selected value.
  const handleSelectPO = (poId) => {
    if (!poId) return;
    const po = availablePOs.find((p) => p.id === poId);
    if (!po) return;
    setEntries((prev) => [...prev, { service_po_id: po.id, label: po.label, hours: '', description: '' }]);
    setAddPoId('');
  };

  const handleRemoveRow = (id) => setEntries((prev) => prev.filter((e) => e.service_po_id !== id));

  const handleEntryChange = (id, field, value) =>
    setEntries((prev) => prev.map((e) => (e.service_po_id === id ? { ...e, [field]: value } : e)));

  const handleSave = async () => {
    setFormError(null);
    if (entries.length === 0) {
      setFormError('Add at least one Service PO entry before saving.');
      return;
    }
    if (entries.some((e) => !(Number(e.hours) > 0))) {
      setFormError('Enter hours greater than 0 for every entry.');
      return;
    }
    if (overCap) {
      setFormError(`Total hours (${formatHoursMinutes(totalHours)}) exceed the ${STANDARD_MONTHLY_HOURS}-hour monthly cap.`);
      return;
    }
    try {
      await saveMutation.mutateAsync({
        employeeId,
        month: monthYear.month,
        year: monthYear.year,
        entries: entries.map((e) => ({
          service_po_id: Number(e.service_po_id),
          sub_project_id: null,
          hours: Number(e.hours),
          description: e.description || '',
        })),
      });
      success(hadExistingEntries ? 'Work log updated for the Employee.' : 'Work log saved for the Employee.');
    } catch (err) {
      // 403 (not mapped / PO not assigned), 400 (cap/duplicate/hierarchy-node), and 422 (month not
      // yet eligible — the eligible check below should already prevent this, but handled
      // defensively too) all land here as one form-level message, not attached to a field.
      setFormError(extractApiError(err));
    }
  };

  const handleDeleteConfirmed = async () => {
    try {
      await deleteMutation.mutateAsync({ employeeId, month: monthYear.month, year: monthYear.year });
      success("This month's work log entries were deleted.");
      setEntries([]);
    } catch (err) {
      setFormError(extractApiError(err));
    } finally {
      setDeleteConfirmOpen(false);
    }
  };

  return (
    <Sheet open={open} onOpenChange={(next) => !saveMutation.isPending && !deleteMutation.isPending && onOpenChange(next)}>
      <SheetContent side="right" className="flex w-full flex-col gap-4 overflow-hidden p-0 sm:max-w-xl">
        <SheetHeader className="border-b px-5 py-4 text-left">
          <SheetTitle>{employee?.full_name ?? 'Employee'}</SheetTitle>
          <SheetDescription>
            {employee?.employee_code ?? ''}{employee?.designation ? ` · ${employee.designation}` : ''} — {monthLabel}
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 space-y-4 overflow-y-auto px-5 pb-5">
          {isLoadingWorkLog ? (
            <div className="space-y-2">
              {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : isWorkLogError ? (
            <EmptyState title={extractApiError(workLogError)} />
          ) : !workLog?.eligible ? (
            <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">
              {monthLabel} hasn&apos;t ended yet — work log hours can only be filled in once a month is complete.
            </div>
          ) : (
            <>
              {formError && (
                <div className="rounded-md border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive">
                  {formError}
                </div>
              )}

              <div className="flex w-full flex-col gap-1.5">
                <Label className="text-xs">Add Service PO</Label>
                <SearchableSelect
                  options={addOptions}
                  value={addPoId}
                  onValueChange={handleSelectPO}
                  placeholder={addOptions.length === 0 ? 'All mapped Service POs added' : 'Select Service PO'}
                  searchPlaceholder="Search Service PO…"
                  disabled={addOptions.length === 0}
                  className="h-11 w-full bg-white sm:h-9"
                />
              </div>

              {entries.length === 0 ? (
                <EmptyState title="No entries yet — add a Service PO above." />
              ) : (
                <div className="space-y-2">
                  {entries.map((entry) => (
                    <div key={entry.service_po_id} className="space-y-2 rounded-xl border bg-white p-3 shadow-sm">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex min-w-0 flex-wrap items-center gap-1.5">
                          <span className="truncate text-sm font-medium">{entry.label}</span>
                          <Badge variant="success" className="shrink-0 text-[10px]">Approved</Badge>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveRow(entry.service_po_id)}
                          className="flex h-8 w-8 shrink-0 items-center justify-center rounded text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                          title="Remove"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="flex flex-col gap-1">
                        <Label className="text-[11px] text-muted-foreground">Hours</Label>
                        <Input
                          type="number"
                          step="0.5"
                          min="0"
                          value={entry.hours}
                          onChange={(e) => handleEntryChange(entry.service_po_id, 'hours', e.target.value)}
                          className="h-11 w-full"
                        />
                      </div>
                      <div className="flex flex-col gap-1">
                        <Label className="text-[11px] text-muted-foreground">Description</Label>
                        <AutoResizeTextarea
                          value={entry.description}
                          onChange={(e) => handleEntryChange(entry.service_po_id, 'description', e.target.value)}
                          placeholder="What did they work on?"
                          rows={1}
                          className="min-h-0 w-full resize-none rounded-md px-2.5 py-1.5 text-sm shadow-sm"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {workLog?.eligible && (
          <div className="flex flex-col gap-3 border-t px-5 py-3">
            <span className={cn('text-sm font-medium', overCap ? 'text-destructive' : 'text-muted-foreground')}>
              Total: {formatHoursMinutes(totalHours)} / {formatHoursMinutes(STANDARD_MONTHLY_HOURS)}
            </span>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="w-full text-destructive sm:w-auto"
                onClick={() => setDeleteConfirmOpen(true)}
                disabled={!hadExistingEntries || deleteMutation.isPending}
                title={hadExistingEntries ? undefined : 'Nothing to delete for this Employee/Month yet'}
              >
                <Trash2 className="mr-1.5 h-4 w-4" /> Delete Month&apos;s Entries
              </Button>
              <Button
                type="button"
                size="sm"
                className="w-full sm:w-auto"
                onClick={handleSave}
                disabled={saveMutation.isPending || entries.length === 0 || overCap}
              >
                <Save className="mr-1.5 h-4 w-4" />
                {saveMutation.isPending ? 'Saving…' : (hadExistingEntries ? 'Update' : 'Save')}
              </Button>
            </div>
          </div>
        )}
      </SheetContent>

      <ConfirmDialog
        open={deleteConfirmOpen}
        onOpenChange={setDeleteConfirmOpen}
        title="Delete this month's work log?"
        description={`This deletes every work log entry for this Employee in ${monthLabel} — not just the entries created here. This can't be undone.`}
        confirmLabel="Delete"
        onConfirm={handleDeleteConfirmed}
        isLoading={deleteMutation.isPending}
      />
    </Sheet>
  );
};

export default ManagerFillWorkLogDrawer;
