import { useMemo, useState } from 'react';
import dayjs from 'dayjs';
import { ChevronRight, Download, PencilLine, Upload, Users } from 'lucide-react';
import { useMyTeamEmployees, useMyTeamEmployeesMonthlyWorkLogTotals } from '@/hooks/useMyTeam';
import PageHeader from '@/components/common/PageHeader';
import SearchInput from '@/components/common/SearchInput';
import BusinessUnitFilter, { ALL_BUS } from '@/components/common/BusinessUnitFilter';
import ManagerFillWorkLogDrawer from '@/components/myTeam/ManagerFillWorkLogDrawer';
import ManagerFillWorkLogBulkUpload, { downloadTemplate } from '@/components/myTeam/ManagerFillWorkLogBulkUpload';
import { formatHoursMinutes } from '@/utils/formatters';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { MonthYearPicker } from '@/components/ui/month-year-picker';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

const MONTH_FULL = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

// Defaults to the most recently COMPLETED month — this screen only ever accepts an already-ended
// month, so opening it on the still-in-progress current month would just land on a blocked
// message every time.
const defaultMonthYear = () => {
  const prev = dayjs().subtract(1, 'month');
  return { month: prev.month() + 1, year: prev.year() };
};

// Client-side gate shared by both modes — a definitive backend `eligible` flag only exists
// per-Employee (Manual Entry's GET .../monthly-worklog), and Bulk Upload has no equivalent
// pre-check endpoint, so this is what blocks BOTH modes up front from the shared Month/Year
// picker, before either an Employee is opened or a file is uploaded.
const monthHasEnded = (monthYear) => {
  if (!monthYear) return false;
  const endOfMonth = dayjs(`${monthYear.year}-${String(monthYear.month).padStart(2, '0')}-01`).endOf('month');
  return dayjs().isAfter(endOfMonth);
};

// Manager self-service, net-new — a Manager fills a mapped Employee's monthly work log hours on
// their behalf, either one Employee at a time (Manual Entry) or many at once via an Excel/CSV
// file (Bulk Upload). Distinct from Timesheet Approval (ManagerTimesheetApproval.jsx), which only
// approves/rejects entries the Employee submitted themself: everything saved here is created
// already-approved, so this is a different action entirely, not another way to reach the same
// review queue.
const ManagerFillWorkLog = () => {
  const [monthYear, setMonthYear] = useState(defaultMonthYear);
  const [mode, setMode] = useState('manual');
  const [search, setSearch] = useState('');
  const [buFilter, setBuFilter] = useState(ALL_BUS);
  const [activeEmployee, setActiveEmployee] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const { data: myEmployees = [], isPending: isLoadingEmployees } = useMyTeamEmployees({
    buId: buFilter !== ALL_BUS ? buFilter : undefined,
  });

  const ended = monthHasEnded(monthYear);

  // Fanned out off the full roster (not the search-filtered rows) so typing in Search never
  // re-triggers these fetches — each Employee's total is cached under the same key the drawer
  // uses, so it's fetched at most once per Employee/Month regardless of which view asks first.
  const workLogTotals = useMyTeamEmployeesMonthlyWorkLogTotals(myEmployees, monthYear, { enabled: ended });

  const filteredEmployees = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return myEmployees;
    return myEmployees.filter((e) =>
      e.employee_code?.toLowerCase().includes(term) ||
      e.full_name?.toLowerCase().includes(term) ||
      e.designation?.toLowerCase().includes(term)
    );
  }, [myEmployees, search]);

  const handleMonthYearChange = (v) => setMonthYear(v ?? defaultMonthYear());

  const handleRowClick = (employee) => {
    setActiveEmployee(employee);
    setDrawerOpen(true);
  };

  const monthLabel = monthYear ? `${MONTH_FULL[monthYear.month - 1]} ${monthYear.year}` : 'this month';

  return (
    <div className="flex h-full min-h-0 flex-col space-y-4">
      <PageHeader
        title="Log Work for My Team"
        description=""
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <SearchInput
              placeholder="Search by code, name, designation…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-[250px]"
              inputClassName="bg-white"
            />
            <BusinessUnitFilter value={buFilter} onChange={setBuFilter} className="h-9 w-56 bg-white" />
            <Button variant="outline" size="sm" onClick={downloadTemplate}>
              <Download className="mr-1.5 h-4 w-4" /> Download Sample
            </Button>
            <MonthYearPicker
              value={monthYear}
              onChange={handleMonthYearChange}
              placeholder="Select month"
              className="h-9 w-44 bg-white"
              clearable={false}
            />
            <Tabs value={mode} onValueChange={setMode}>
              <TabsList>
                <TabsTrigger value="manual" className="gap-1.5">
                  <PencilLine className="h-3.5 w-3.5" /> Manual Entry
                </TabsTrigger>
                <TabsTrigger value="bulk" className="gap-1.5">
                  <Upload className="h-3.5 w-3.5" /> Import Excel
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        }
      />

      {!ended ? (
        <div className="rounded-md border bg-muted/30 p-4 text-sm text-muted-foreground">
          {monthLabel} hasn&apos;t ended yet — work log hours can only be filled in once a month is complete.
          Pick an earlier month to continue.
        </div>
      ) : mode === 'manual' ? (
        <>
          <div className="rounded-lg border bg-white">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Designation</TableHead>
                  <TableHead>Total Hours</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoadingEmployees ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell colSpan={4}><Skeleton className="h-5 w-full" /></TableCell>
                    </TableRow>
                  ))
                ) : filteredEmployees.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="py-10 text-center text-sm text-muted-foreground">
                      <Users className="mx-auto mb-2 h-8 w-8 text-muted-foreground/50" />
                      {myEmployees.length === 0 ? 'No Employees reporting to you yet.' : 'No Employees match your search/filter.'}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredEmployees.map((employee) => (
                    <TableRow
                      key={employee.id}
                      className="cursor-pointer hover:bg-muted/40"
                      onClick={() => handleRowClick(employee)}
                    >
                      <TableCell>
                        <div className="text-sm font-medium">{employee.full_name}</div>
                        <div className="text-xs text-muted-foreground">{employee.employee_code}</div>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">{employee.designation ?? '—'}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {workLogTotals.get(employee.id)?.isLoading ? (
                          <Skeleton className="h-4 w-14" />
                        ) : (
                          formatHoursMinutes(workLogTotals.get(employee.id)?.totalHours ?? 0)
                        )}
                      </TableCell>
                      <TableCell>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </>
      ) : (
        <ManagerFillWorkLogBulkUpload monthYear={monthYear} monthLabel={monthLabel} />
      )}

      {activeEmployee && (
        <ManagerFillWorkLogDrawer
          key={activeEmployee.id}
          employee={activeEmployee}
          monthYear={monthYear}
          monthLabel={monthLabel}
          open={drawerOpen}
          onOpenChange={setDrawerOpen}
        />
      )}
    </div>
  );
};

export default ManagerFillWorkLog;
