import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { createColumnHelper } from '@tanstack/react-table';
import { Upload, Info, Download, Trash2, Loader2, RefreshCw } from 'lucide-react';
import * as XLSX from 'xlsx';
import { useTimesheetHistory, useDeleteTimesheetImport, useDeleteTimesheetImports } from '@/hooks/useTimesheets';
import { useCanViewOriginalData } from '@/hooks/usePermissions';
import { useAuth } from '@/hooks/useAuth';
import { useCompanies } from '@/hooks/useCompanies';
import { timesheetsApi } from '@/api/timesheets.api';
import { QUERY_KEYS } from '@/constants/queryKeys';
import { useNotification } from '@/hooks/useNotification';
import { extractApiError } from '@/services/apiClient';
import { ROUTES, buildPath } from '@/constants/routes';
import { formatDate } from '@/utils/formatters';
import DataTable from '@/components/common/DataTable';
import PageHeader from '@/components/common/PageHeader';
import ConfirmDialog from '@/components/common/ConfirmDialog';
import FilterToggleButton from '@/components/common/FilterToggleButton';
import FilterPanel from '@/components/common/FilterPanel';
import EntityFilter from '@/components/common/EntityFilter';
import BusinessUnitFilter from '@/components/common/BusinessUnitFilter';
import SyncWorkLogsDialog from '@/components/timesheets/SyncWorkLogsDialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { SearchableSelect } from '@/components/ui/searchable-select';
import { Label } from '@/components/ui/label';
import { MonthYearPicker } from '@/components/ui/month-year-picker';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const columnHelper = createColumnHelper();


const TimesheetList = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { success, error: showError } = useNotification();
  const canViewOriginal = useCanViewOriginalData();
  const { businessUnits } = useAuth();
  // Sync must only offer BUs the employee can still act against — an employee's own BU mapping
  // survives its BU being deactivated later, so filter here rather than trusting useAuth's raw
  // list. Missing `status` (mock mode, or any source that doesn't send it) defaults to active,
  // matching utils/organizationOverview.js's same fallback.
  const rawActiveBusinessUnits = useMemo(
    () => businessUnits.filter((bu) => (bu.status ?? 'active') === 'active'),
    [businessUnits]
  );

  // The login's own BU mapping (GET /employees/:id/business-units) doesn't carry entity info —
  // confirmed live, an Entity dropdown built straight off it came back empty. The company master
  // does, so it's looked up here and merged in. Safe for any login this query 403s for: it just
  // comes back empty and every BU's entity_id stays null, same as before this lookup existed.
  const { data: companiesForEntityLookup } = useCompanies(
    { status: 'active', limit: 200 },
    { staleTime: 1000 * 60 * 10 }
  );
  const entityByBuId = useMemo(() => {
    const map = new Map();
    (companiesForEntityLookup?.data ?? []).forEach((c) => {
      const id = c.entity_id ?? c.entity?.id;
      const name = c.entity?.entity_name;
      if (id != null) map.set(String(c.id), { id, name });
    });
    return map;
  }, [companiesForEntityLookup]);
  const activeBusinessUnits = useMemo(
    () => rawActiveBusinessUnits.map((bu) => {
      const looked = entityByBuId.get(String(bu.id));
      return {
        ...bu,
        entity_id: bu.entity_id ?? bu.entityId ?? looked?.id ?? null,
        entity_name: bu.entity_name ?? bu.entityName ?? looked?.name ?? null,
      };
    }),
    [rawActiveBusinessUnits, entityByBuId]
  );

  // Distinct Entities across this login's own mapped BUs — feeds the Entity step in the Sync/
  // Upload dialogs below, which (unlike the list's EntityFilter/BusinessUnitFilter pair) can only
  // ever target a BU this login is actually mapped to, not the full company master.
  const buEntityOptions = useMemo(() => {
    const byId = new Map();
    activeBusinessUnits.forEach((bu) => {
      const id = bu.entity_id ?? bu.entityId;
      const name = bu.entity_name ?? bu.entityName;
      if (id != null && name && !byId.has(id)) byId.set(id, { id, name });
    });
    return Array.from(byId.values());
  }, [activeBusinessUnits]);

  const buOptionsForEntity = (entityId) =>
    entityId && entityId !== 'all'
      ? activeBusinessUnits.filter((bu) => String(bu.entity_id ?? bu.entityId) === String(entityId))
      : activeBusinessUnits;

  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);

  const currentDate = new Date();
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [uploadEntityId, setUploadEntityId] = useState('all');
  const [uploadBuId, setUploadBuId] = useState('');
  const [isSyncDialogOpen, setIsSyncDialogOpen] = useState(false);
  const [uploadMonthYear, setUploadMonthYear] = useState({ month: currentDate.getMonth() + 1, year: currentDate.getFullYear() });
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [selectedIds, setSelectedIds] = useState([]);
  const [isBulkDeleteOpen, setIsBulkDeleteOpen] = useState(false);
  const [monthYearFilter, setMonthYearFilter] = useState(null);
  const [entityFilter, setEntityFilter] = useState('all');
  const [buFilter, setBuFilter] = useState('all');
  const [openingId, setOpeningId] = useState(null);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const [sorting, setSorting] = useState([]);

  const params = {
    page,
    limit,
    buId: buFilter,
    ...(monthYearFilter && { month: monthYearFilter.month, year: monthYearFilter.year }),
    ...(sorting[0] && { sortBy: sorting[0].id, sortOrder: sorting[0].desc ? 'desc' : 'asc' }),
  };

  const { data, isPending } = useTimesheetHistory(params);
  const deleteMutation = useDeleteTimesheetImport();
  const bulkDeleteMutation = useDeleteTimesheetImports();

  const activeFilterCount =
    (monthYearFilter ? 1 : 0) + (entityFilter !== 'all' ? 1 : 0) + (buFilter !== 'all' ? 1 : 0);

  const clearFilters = () => {
    setMonthYearFilter(null);
    setEntityFilter('all');
    setBuFilter('all');
    setPage(1);
    setSelectedIds([]);
  };

  const allRecords = Array.isArray(data?.data) ? data.data : [];
  const records    = allRecords.filter((r) => r.status === 'completed');
  const meta       = data?.meta ?? {};

  const allSelected = records.length > 0 && records.every((r) => selectedIds.includes(r.id));
  const toggleSelectAll = () => setSelectedIds(allSelected ? [] : records.map((r) => r.id));
  const toggleSelect = (id) =>
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  const handleDownloadSample = () => {
    const wsData = [
      ['Employee Code', 'Name', 'Project 1', 'Project 2', 'Is Working'],
      ['EMP-0201', 'Aditya Uday patil', '00:00:00', '00:10:00', 'F'],
    ];

    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const wb = XLSX.utils.book_new();

    ws['!cols'] = [
      { wch: 15 },
      { wch: 25 },
      { wch: 20 },
      { wch: 20 },
      { wch: 12 },
    ];

    const currentMonth = new Date().toLocaleString('default', { month: 'short' });
    XLSX.utils.book_append_sheet(wb, ws, currentMonth);
    XLSX.writeFile(wb, 'Timesheet_Sample.xlsx');
  };

  // Excel upload lands rows against exactly one BU — asked up front
  // in the "Select Period" dialog instead of a separate step since that dialog is a single screen.
  const handleUploadClick = () => {
    setUploadEntityId('all');
    setUploadBuId(activeBusinessUnits.length === 1 ? String(activeBusinessUnits[0].id) : '');
    setIsUploadDialogOpen(true);
  };

  const handleDelete = () => {
    deleteMutation.mutate(deleteTarget.id, {
      onSuccess: () => {
        success(`Import "${deleteTarget.file_name}" has been deleted.`);
        setDeleteTarget(null);
      },
      onError: (err) => showError(extractApiError(err)),
    });
  };

  const handleBulkDelete = () => {
    const count = selectedIds.length;
    bulkDeleteMutation.mutate(selectedIds, {
      onSuccess: () => {
        success(`${count} import${count !== 1 ? 's' : ''} deleted.`);
        setSelectedIds([]);
        setIsBulkDeleteOpen(false);
      },
      onError: (err) => showError(extractApiError(err)),
    });
  };

  const columns = [
    columnHelper.display({
      id: 'select',
      header: () => (
        <Checkbox
          checked={allSelected}
          onCheckedChange={toggleSelectAll}
          aria-label="Select all"
        />
      ),
      size: 36,
      cell: ({ row }) => (
        <div onClick={(e) => e.stopPropagation()}>
          <Checkbox
            checked={selectedIds.includes(row.original.id)}
            onCheckedChange={() => toggleSelect(row.original.id)}
            aria-label="Select row"
          />
        </div>
      ),
    }),
    columnHelper.display({
      id: 'actions',
      header: 'Actions',
      size: 90,
      cell: ({ row }) => (
        <div onClick={(e) => e.stopPropagation()}>
          <Button
            size="sm"
            className="h-6 w-6 p-0 bg-red-500 hover:bg-red-600 text-white rounded transition-colors"
            title="Delete"
            onClick={() => setDeleteTarget(row.original)}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      ),
    }),
    columnHelper.accessor('file_name', {
      header: 'File Name',
      size: 150,
      cell: (info) => (
        <div className="flex items-center gap-2 max-w-[150px]">
          <span className="font-medium text-sm truncate" title={info.getValue()}>
            {info.getValue() ?? '—'}
          </span>
          {openingId === info.row.original.id && (
            <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-primary" />
          )}
        </div>
      ),
    }),
    columnHelper.accessor('importer', {
      header: 'Imported By',
      size: 200,
      cell: (info) => {
        const imp = info.getValue();
        const name = imp?.employee?.full_name ?? imp?.email ?? '—';
        const code = imp?.employee?.employee_code;
        return (
          <div className="max-w-[190px]">
            <p className="text-sm font-medium truncate" title={name}>{name}</p>
            {code && <p className="text-xs text-muted-foreground font-mono truncate">{code}</p>}
          </div>
        );
      },
    }),
    columnHelper.accessor('total_rows', {
      // Sized to fit the label plus its sort icon — DataTable pins size as a hard width and
      // truncates the header text inside it, so anything narrower renders as "T...".
      header: 'Total Rows',
      size: 130,
      cell: (info) => (
        <span className="tabular-nums text-sm">{info.getValue() ?? '—'}</span>
      ),
    }),
    // columnHelper.accessor('valid_rows', {
    //   header: 'Valid',
    //   size: 70,
    //   cell: (info) => (
    //     <span className="tabular-nums text-sm text-green-600 font-medium">{info.getValue() ?? '—'}</span>
    //   ),
    // }),
    // columnHelper.accessor('error_rows', {
    //   header: 'Errors',
    //   size: 70,
    //   cell: (info) => {
    //     const v = info.getValue();
    //     return (
    //       <span className={`tabular-nums text-sm font-medium ${v > 0 ? 'text-destructive' : 'text-muted-foreground'}`}>
    //         {v ?? '—'}
    //       </span>
    //     );
    //   },
    // }),
    columnHelper.accessor('total_employees', {
      header: 'Employees',
      size: 130,
      cell: (info) => {
        const v = info.getValue();
        return (
          <span className="tabular-nums text-sm font-medium text-blue-600">
            {v ?? '—'}
          </span>
        );
      },
    }),
    ...(canViewOriginal ? [columnHelper.accessor('is_publish', {
      header: 'Status',
      size: 100,
      cell: (info) => {
        const v = !!info.getValue();
        return (
          <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ${v ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400' : 'bg-muted text-muted-foreground'}`}>
            {v ? 'Published' : 'Unpublished'}
          </span>
        );
      },
    })] : []),
    columnHelper.accessor('created_at', {
      header: 'Imported At',
      size: 150,
      cell: (info) => (
        <span className="text-xs text-muted-foreground tabular-nums">
          {formatDate(info.getValue())}
        </span>
      ),
    }),
  ];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Timesheet Imports"
        description="History of all uploaded timesheet files"
        actions={
          <div className="flex items-center gap-2">
            <FilterToggleButton
              isOpen={filtersOpen}
              onToggle={() => setFiltersOpen((prev) => !prev)}
              activeCount={activeFilterCount}
            />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-xs text-xs space-y-1">
                  <ul className="list-disc pl-3">
                    <li>Worksheet name should be short of month like Jan, Feb etc.</li>
                    <li>The employee and project should be present in their respective masters with status active</li>
                  </ul>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <Button variant="outline" size="sm" onClick={handleDownloadSample}>
              <Download className="mr-1.5 h-4 w-4" />
              Download Sample
            </Button>
            <Button variant="outline" size="sm" onClick={() => setIsSyncDialogOpen(true)}>
              <RefreshCw className="mr-1.5 h-4 w-4" />
              Sync Employee Work Logs
            </Button>
            {canViewOriginal && (
              <Button size="sm" onClick={handleUploadClick}>
                <Upload className="mr-1.5 h-4 w-4" />
                Upload Excel
              </Button>
            )}
          </div>
        }
      />

      <FilterPanel
        isOpen={filtersOpen}
        maxHeightClass="max-h-[140px]"
        gridClassName="grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 w-full"
        onClear={clearFilters}
        showClear={activeFilterCount > 0}
      >
        <EntityFilter
          value={entityFilter}
          onChange={(v) => { setEntityFilter(v); setBuFilter('all'); setPage(1); setSelectedIds([]); }}
        />
        <BusinessUnitFilter
          value={buFilter}
          entityId={entityFilter}
          onChange={(v) => { setBuFilter(v); setPage(1); setSelectedIds([]); }}
        />
        <div className="flex flex-col gap-1.5">
          <Label className="text-xs">Month &amp; Year</Label>
          <MonthYearPicker
            value={monthYearFilter}
            onChange={(val) => { setMonthYearFilter(val); setPage(1); setSelectedIds([]); }}
            placeholder="All months"
            className="w-44"
          />
        </div>
      </FilterPanel>

      {selectedIds.length > 0 && (
        <div className="flex items-center justify-between rounded-lg border bg-muted/30 px-3 py-2">
          <span className="text-sm font-medium">{selectedIds.length} selected</span>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setSelectedIds([])}>
              Clear
            </Button>
            <Button
              size="sm"
              className="bg-red-500 hover:bg-red-600 text-white"
              onClick={() => setIsBulkDeleteOpen(true)}
            >
              <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Delete Selected
            </Button>
          </div>
        </div>
      )}

      <DataTable
        columns={columns}
        data={records}
        isLoading={isPending}
        toolbar={null}
        pagination={
          records.length > 0
            ? {
                page:  1,
                limit: records.length,
                total: records.length,
              }
            : undefined
        }
        sorting={sorting}
        onSortingChange={(s) => { setSorting(s); setPage(1); }}
        onPageChange={(p) => { setPage(p); setSelectedIds([]); }}
        onPageSizeChange={(s) => { setLimit(s); setPage(1); setSelectedIds([]); }}
        rowClassName={(row) => (openingId && openingId !== row.id ? 'opacity-50 pointer-events-none' : '')}
        onRowClick={async (row) => {
          if (openingId) return;
          setOpeningId(row.id);
          // Prefetch the (potentially large) row set so the spinner covers the
          // whole wait here, and the details page mounts with data already cached
          // instead of showing its own skeleton right after this one.
          try {
            await queryClient.prefetchQuery({
              queryKey: QUERY_KEYS.TIMESHEET_IMPORT_ROWS(String(row.id)),
              queryFn: () => timesheetsApi.getImportRows(row.id),
            });
          } finally {
            navigate(buildPath(ROUTES.TIMESHEET_IMPORT_DETAIL, { id: row.id }));
          }
        }}
      />

      <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>Select Period</DialogTitle>
            <DialogDescription>
              Choose the month and year for this timesheet import.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label>Month &amp; Year</Label>
              <MonthYearPicker value={uploadMonthYear} onChange={setUploadMonthYear} clearable={false} className="w-full" />
            </div>
            {/* Same "which BU does this land in" question as Sync's dialog, asked inline here
                since Upload is already a single-step dialog — only shown when there's an actual
                choice to make (see handleUploadClick). */}
            {activeBusinessUnits.length > 1 && (
              <>
                {buEntityOptions.length > 1 && (
                  <div className="grid gap-2">
                    <Label>Entity</Label>
                    <SearchableSelect
                      options={[{ label: 'All Entities', value: 'all' }, ...buEntityOptions.map((e) => ({ label: e.name, value: String(e.id) }))]}
                      value={uploadEntityId}
                      onValueChange={(v) => { setUploadEntityId(v ?? 'all'); setUploadBuId(''); }}
                      placeholder="All Entities"
                      searchPlaceholder="Search entity..."
                      showSearch={buEntityOptions.length > 6}
                    />
                  </div>
                )}
                <div className="grid gap-2">
                  <Label>Business Unit</Label>
                  <SearchableSelect
                    options={buOptionsForEntity(uploadEntityId).map((bu) => ({ label: bu.name, value: String(bu.id) }))}
                    value={uploadBuId}
                    onValueChange={setUploadBuId}
                    placeholder="Select a Business Unit"
                    searchPlaceholder="Search business unit..."
                    showSearch={activeBusinessUnits.length > 6}
                  />
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              disabled={activeBusinessUnits.length > 1 && !uploadBuId}
              onClick={() => {
                setIsUploadDialogOpen(false);
                navigate(ROUTES.TIMESHEET_UPLOAD, { state: { month: uploadMonthYear.month, year: uploadMonthYear.year, buId: uploadBuId || null } });
              }}
            >
              Continue
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <SyncWorkLogsDialog
        open={isSyncDialogOpen}
        onOpenChange={setIsSyncDialogOpen}
        activeBusinessUnits={activeBusinessUnits}
      />

      <ConfirmDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
        title="Delete this upload?"
        description={`This will permanently remove "${deleteTarget?.file_name}" and all ${deleteTarget?.total_rows ?? ''} timesheet rows it imported. This cannot be undone.`}
        confirmLabel="Delete"
        onConfirm={handleDelete}
        isLoading={deleteMutation.isPending}
      />

      <ConfirmDialog
        open={isBulkDeleteOpen}
        onOpenChange={setIsBulkDeleteOpen}
        title={`Delete ${selectedIds.length} upload${selectedIds.length !== 1 ? 's' : ''}?`}
        description="This will permanently remove the selected imports and all timesheet rows they contain. This cannot be undone."
        confirmLabel="Delete"
        onConfirm={handleBulkDelete}
        isLoading={bulkDeleteMutation.isPending}
      />
    </div>
  );
};

export default TimesheetList;
