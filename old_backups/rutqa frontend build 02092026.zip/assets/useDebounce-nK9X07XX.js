import{r as o}from"./redux-CPPG5m42.js";const n=(e,t=400)=>{const[r,s]=o.useState(e);return o.useEffect(()=>{const u=setTimeout(()=>s(e),t);return()=>clearTimeout(u)},[e,t]),r};export{n as u};
