import{j as m}from"./query-Bjlkq4Bn.js";import{L as o}from"./index-B7IgW3D6.js";const r=({className:s,...e})=>m.jsx("div",{className:o("animate-pulse rounded-md bg-muted",s),...e});export{r as S};
