const o=({month:t,year:n})=>`${n}-${String(t).padStart(2,"0")}`,p=t=>{if(!t)return null;const[n,r]=t.split("-").map(Number);return{month:r,year:n}};export{p as f,o as t};
